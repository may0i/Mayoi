importScripts('./catalog.js', './archive-storage.js');

const storage = self.archiveStorage;
const scope = new URL(self.registration.scope);
const idPattern = /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/;

self.addEventListener('install', event => event.waitUntil(self.skipWaiting()));
self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  const prefix = `${scope.pathname}api/`;
  if (url.origin === scope.origin && url.pathname.startsWith(prefix)) {
    event.respondWith(handleApi(event.request, url.pathname.slice(prefix.length), url.searchParams));
  }
});

class ApiError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

async function serveMedia(request, id, kind, download) {
  const { info, file } = await storage.getMedia(id, kind);
  const headers = { 'Content-Type': info.type === 'text/plain' ? 'text/plain; charset=utf-8' : info.type,
    'Accept-Ranges': 'bytes', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' };
  if (download) {
    const filename = encodeURIComponent(info.name).replace(/['()*]/g, char => `%${char.charCodeAt(0).toString(16)}`);
    headers['Content-Disposition'] = `attachment; filename*=UTF-8''${filename}`;
  }
  let start = 0;
  let end = file.size - 1;
  let status = 200;
  const range = /^bytes=(\d*)-(\d*)$/.exec(request.headers.get('Range') || '');
  if (range && (range[1] || range[2])) {
    if (range[1]) {
      start = Number(range[1]);
      if (range[2]) end = Math.min(end, Number(range[2]));
    } else {
      start = Math.max(0, file.size - Number(range[2]));
    }
    if (start >= file.size || start > end) return new Response(null, { status: 416, headers: { 'Content-Range': `bytes */${file.size}` } });
    status = 206;
    headers['Content-Range'] = `bytes ${start}-${end}/${file.size}`;
  }
  headers['Content-Length'] = end - start + 1;
  return new Response(request.method === 'HEAD' ? null : file.slice(start, end + 1), { status, headers });
}

async function handleApi(request, path, params) {
  const { method } = request;
  try {
    if (path === 'links' && method === 'GET') return await fetch(new URL('links.json', scope));
    if (path === 'works' && method === 'GET') return Response.json(await storage.listWorks(false));
    if (path === 'works' && method === 'POST') return Response.json(await storage.addWork(await request.formData()), { status: 201 });
    if (path === 'trash' && method === 'GET') return Response.json(await storage.listWorks(true));
    const [group, id, kind, extra] = path.split('/');
    if (extra !== undefined || !idPattern.test(id || '')) throw new ApiError(404, '作品が見つかりません。');
    if (group === 'works') {
      if (['primary', 'reverse', 'audio'].includes(kind) && ['GET', 'HEAD'].includes(method)) {
        return await serveMedia(request, id, kind, params.has('download'));
      }
      if (!kind && method === 'GET') return Response.json(await storage.getWork(id));
      if (!kind && method === 'PATCH') return Response.json(await storage.editWork(id, await request.json()));
      if (!kind && method === 'DELETE') return Response.json(await storage.moveWork(id, true));
    }
    if (group === 'trash' && !kind && method === 'POST') return Response.json(await storage.moveWork(id, false));
    if (group === 'trash' && !kind && method === 'DELETE') return Response.json(await storage.purgeWork(id));
    throw new ApiError(404, 'ページが見つかりません。');
  } catch (error) {
    return Response.json({ message: storage.failureMessage(error) }, { status: error.status || 500 });
  }
}
