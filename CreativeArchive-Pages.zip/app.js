const { categories, formats, titleLimit, memoLimit } = window.archiveCatalog;
const storage = window.archiveStorage;
const page = document.body.dataset.page;
const main = document.querySelector('#main');
const params = new URLSearchParams(location.search);
const folders = Object.entries(categories).filter(([, category]) => category.format === 'note');
const dateFormat = new Intl.DateTimeFormat('ja-JP', { dateStyle: 'medium' });

const links = {
  home: './', music: './music.html', art: './art.html', import: './import.html',
};

function element(tag, attributes = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attributes)) {
    if (value !== undefined && value !== null && value !== false) {
      node.setAttribute(key, value === true ? '' : value);
    }
  }
  node.append(...children);
  return node;
}

function link(text, href, className, attributes = {}) {
  return element('a', { href, class: className, ...attributes }, text);
}

function button(text, attributes = {}) {
  return element('button', { type: 'button', ...attributes }, text);
}

const mediaSources = new Map();

function mediaSource(work, kind = 'primary') {
  const key = `${work.id}/${kind}`;
  if (!mediaSources.has(key)) {
    mediaSources.set(key, storage.getMedia(work.id, kind).then(({ file }) => URL.createObjectURL(file)).catch(error => {
      mediaSources.delete(key);
      throw error;
    }));
  }
  return mediaSources.get(key);
}

function galleryImage(work, kind = 'primary') {
  const image = element('img', { alt: '', loading: 'lazy', decoding: 'async' });
  mediaSource(work, kind).then(source => { image.src = source; }).catch(() => { image.alt = '画像を読み込めませんでした'; });
  return image;
}

function detailUrl(id) {
  return `./work.html?id=${encodeURIComponent(id)}`;
}

function collectionUrl(category) {
  if (category === 'score') return links.music;
  if (category === 'illustration') return links.art;
  if (category === 'other-art') return `${links.art}?category=other-art`;
  return `${links.music}?view=notes&folder=${encodeURIComponent(category)}`;
}

function navLink(text, destination, active, className) {
  return link(text, links[destination], className, { 'aria-current': active === destination ? 'page' : null });
}

function renderHeader(active = page) {
  const brand = element('a', { href: links.home, class: 'brand', 'aria-label': '間宵の創作室 ホーム' },
    element('span', { class: 'brand-mark', 'aria-hidden': 'true' }),
    element('span', { class: 'brand-name' }, '間宵の創作室'));
  const nav = element('nav', { class: 'site-nav', 'aria-label': 'メインメニュー' },
    navLink('ホーム', 'home', active),
    navLink('音楽置き場', 'music', active),
    navLink('イラスト置き場', 'art', active));
  const add = navLink('ファイルを追加', 'import', active, 'button button-dark header-add');
  document.querySelector('#masthead').replaceChildren(element('div', { class: 'header-inner' }, brand, nav, add));
}

function renderFooter() {
  const trashButton = button('ゴミ箱', { class: 'button button-light', 'aria-haspopup': 'dialog' });
  trashButton.addEventListener('click', () => openTrash());
  document.querySelector('#footer').replaceChildren(element('div', { class: 'shell footer-inner' },
    link('間宵の創作室', links.home, 'footer-brand'),
    trashButton));
}

function sectionHeading(japanese, english, id) {
  return element('div', { class: 'section-heading' },
    element('h2', { id }, japanese), element('span', { class: 'eyebrow' }, english));
}

function pageHeading(japanese, english, description) {
  const header = element('header', { class: 'page-heading' },
    element('p', { class: 'eyebrow' }, english), element('h1', {}, japanese));
  if (description) header.append(element('p', { class: 'muted' }, description));
  return header;
}

function notice(title, description, action) {
  const box = element('div', { class: 'notice' }, element('h2', {}, title),
    element('p', { class: 'muted' }, description));
  if (action) box.append(action);
  return box;
}

function confirmedAction(label, { title, message, confirmLabel, perform, afterSuccess }, attributes = {}) {
  const trigger = button(label, { class: 'button button-danger', 'aria-haspopup': 'dialog', ...attributes });
  trigger.addEventListener('click', () => {
    const cancel = button('キャンセル', { class: 'button button-light' });
    const confirm = button(confirmLabel, { class: 'button button-danger', type: 'submit' });
    const status = element('p', { class: 'form-status', role: 'status' });
    const form = element('form', {},
      element('h2', { id: 'confirmation-title' }, title),
      element('p', { id: 'confirmation-description', class: 'muted' }, message),
      element('div', { class: 'actions' }, cancel, confirm), status);
    const dialog = element('dialog', { class: 'confirmation-dialog', 'aria-labelledby': 'confirmation-title',
      'aria-describedby': 'confirmation-description' }, form);
    cancel.addEventListener('click', () => dialog.close());
    dialog.addEventListener('cancel', event => {
      if (confirm.disabled) event.preventDefault();
    });
    dialog.addEventListener('close', () => dialog.remove(), { once: true });
    form.addEventListener('submit', async event => {
      event.preventDefault();
      cancel.disabled = confirm.disabled = true;
      status.textContent = '処理中…';
      try {
        await perform();
      } catch (error) {
        status.textContent = error.message;
        cancel.disabled = confirm.disabled = false;
        return;
      }
      dialog.close();
      afterSuccess?.();
    });

    document.body.append(dialog);
    dialog.showModal();
    cancel.focus();
  });
  return trigger;
}

function carousel(slides, { id, label, className, startAt = 0 }) {
  const viewport = element('div', { id, class: 'carousel-viewport', role: 'region', 'aria-label': label, tabindex: '0' }, ...slides);
  const previous = button('前へ', { class: 'button button-light', 'aria-controls': id, 'aria-label': `${label}を前へ`, disabled: true });
  const next = button('次へ', { class: 'button button-light', 'aria-controls': id, 'aria-label': `${label}を次へ` });
  const controls = element('div', { class: 'carousel-controls', hidden: true },
    element('span', { class: 'carousel-hint' }, '横にスワイプ'),
    element('div', { class: 'carousel-buttons' }, previous, next));
  const node = element('div', { class: `carousel ${className}` }, controls, viewport);

  const maxScroll = () => Math.max(0, viewport.scrollWidth - viewport.clientWidth);
  const snapPoints = () => {
    const origin = slides[0].offsetLeft;
    const limit = maxScroll();
    return slides.map(slide => Math.min(slide.offsetLeft - origin, limit));
  };

  function updateControls() {
    const limit = maxScroll();
    const position = viewport.scrollLeft;
    controls.hidden = limit <= 2;
    viewport.tabIndex = controls.hidden ? -1 : 0;
    previous.disabled = position <= 2;
    next.disabled = position >= limit - 2;
  }

  function scrollTo(position) {
    const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
    viewport.scrollTo({ left: position, behavior: reduceMotion ? 'auto' : 'smooth' });
  }

  function move(direction) {
    const position = viewport.scrollLeft;
    const points = snapPoints();
    const target = direction > 0 ? points.find(point => point > position + 2) : points.findLast(point => point < position - 2);
    if (target !== undefined) scrollTo(target);
  }

  previous.addEventListener('click', () => move(-1));
  next.addEventListener('click', () => move(1));
  viewport.addEventListener('scroll', updateControls, { passive: true });
  viewport.addEventListener('keydown', event => {
    if (event.target !== viewport || !['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
    event.preventDefault();
    move(event.key === 'ArrowRight' ? 1 : -1);
  });

  let drag;
  let dragged = false;
  viewport.addEventListener('pointerdown', event => {
    dragged = false;
    if (event.pointerType === 'mouse' && event.button === 0 && maxScroll() > 2) {
      drag = { pointer: event.pointerId, start: event.clientX, scroll: viewport.scrollLeft };
    }
  });
  viewport.addEventListener('pointermove', event => {
    if (!drag || event.pointerId !== drag.pointer || !(event.buttons & 1)) return;
    const distance = event.clientX - drag.start;
    if (!dragged && Math.abs(distance) < 6) return;
    if (!dragged) {
      dragged = true;
      viewport.setPointerCapture(event.pointerId);
      viewport.classList.add('is-dragging');
    }
    viewport.scrollLeft = drag.scroll - distance;
  });

  function stopDrag(event) {
    if (!drag || event.pointerId !== drag.pointer) return;
    drag = undefined;
    if (!dragged) return;
    const position = viewport.scrollLeft;
    const closest = snapPoints().reduce((best, point) =>
      Math.abs(point - position) < Math.abs(best - position) ? point : best);
    viewport.classList.remove('is-dragging');
    scrollTo(closest);
  }

  viewport.addEventListener('pointerup', stopDrag);
  viewport.addEventListener('pointercancel', stopDrag);
  viewport.addEventListener('pointerleave', () => {
    if (!dragged) drag = undefined;
  });
  viewport.addEventListener('dragstart', event => event.preventDefault());
  viewport.addEventListener('click', event => {
    if (dragged && event.detail > 0) {
      event.preventDefault();
      event.stopPropagation();
    }
    dragged = false;
  }, true);

  const observer = new ResizeObserver(updateControls);
  observer.observe(viewport);
  const initialFrame = requestAnimationFrame(() => {
    if (startAt) viewport.scrollLeft = snapPoints()[startAt];
    updateControls();
  });
  return { node, dispose() { observer.disconnect(); cancelAnimationFrame(initialFrame); } };
}

function homeCollection(title, english, icon, url, children) {
  const heading = element('a', { href: url, class: 'collection-heading' },
    element('span', { class: `collection-icon ${icon}`, 'aria-hidden': 'true' }, icon === 'music-icon' ? '𝄞' : ''),
    element('span', {}, element('span', { class: 'collection-name' }, title),
      element('span', { class: 'eyebrow' }, english)));
  return element('article', { class: 'collection-card' }, heading,
    element('div', { class: 'collection-links' }, ...children));
}

async function renderHome() {
  const hero = element('section', { class: 'hero', 'aria-labelledby': 'title' },
    element('div', { class: 'hero-copy' },
      element('p', { class: 'eyebrow' }, 'Creative Archive'),
      element('h1', { id: 'title' }, '間宵の創作室'),
      element('p', { class: 'hero-summary' }, '楽譜、練習の記録、イラストをひとつの場所に。')),
    element('figure', { class: 'hero-figure' },
      element('img', { src: './assets/studio.png', width: 600, height: 600, alt: '眼鏡とマスクを着けた人物のプロフィールイラスト' })));

  const collections = element('section', { id: 'collections', class: 'home-section', 'aria-labelledby': 'collections-title' },
    sectionHeading('作品アーカイブ', 'Portfolio Archive', 'collections-title'),
    element('div', { class: 'collections' },
      homeCollection('音楽置き場', 'Music Archive', 'music-icon', links.music, [
        link('楽譜', links.music, 'collection-link'),
        link('練習メモ・資料', `${links.music}?view=notes`, 'collection-link'),
      ]),
      homeCollection('イラスト置き場', 'Illustration Archive', 'art-icon', links.art, [
        link('挿絵', links.art, 'collection-link'),
        link('その他', `${links.art}?category=other-art`, 'collection-link'),
      ])));
  main.append(hero, collections);

  const response = await fetch('./links.json');
  if (!response.ok) return;
  const external = await response.json();
  const labels = { instagram: 'Instagram', note: 'note', youtube: 'YouTube' };
  const tiles = Object.entries(external).map(([name, url]) =>
    element('a', { class: 'external-card', href: url, target: '_blank', rel: 'noopener noreferrer' },
      element('span', { class: `service-icon ${name}`, 'aria-hidden': 'true' }), labels[name]));
  if (tiles.length) {
    main.append(element('section', { class: 'home-section', 'aria-labelledby': 'external-title' },
      sectionHeading('外部リンク', 'External Links', 'external-title'),
      element('div', { class: 'external-links' }, ...tiles)));
  }
}

function flipIllustration(work, sources) {
  const face = (kind, className) => element('span', { class: `flip-face ${className}` },
    sources ? element('img', { src: sources[kind], alt: '', decoding: 'async' }) : galleryImage(work, kind));
  const label = element('span', { class: 'flip-label' }, '裏面を見る');
  const sheet = element('span', { class: 'flip-sheet', 'aria-hidden': 'true' },
    face('primary', 'flip-front'), face('reverse', 'flip-back'));
  const control = element('button', { type: 'button', class: 'flip-illustration', 'aria-pressed': 'false',
    'aria-label': `${work.title}の裏面を表示` }, sheet, label);
  let kind = 'primary';
  control.addEventListener('click', () => {
    const back = kind === 'primary';
    kind = back ? 'reverse' : 'primary';
    control.classList.toggle('show-back', back);
    control.setAttribute('aria-pressed', String(back));
    label.textContent = back ? '表面に戻す' : '裏面を見る';
  });
  return { control, currentSide: () => kind };
}

function workCard(work) {
  const category = categories[work.category];
  const metadata = [category.label];
  if (work.audio) metadata.push('試聴あり');
  const copy = element('div', { class: 'work-copy' }, element('h3', {}, work.title),
    element('p', { class: 'work-meta' }, metadata.join(' · ')));
  if (work.reverse) {
    const { control } = flipIllustration(work);
    copy.append(element('span', { class: 'work-detail-label' }, '詳細・編集'));
    return element('article', { class: 'work-card paired-work' }, control,
      link(copy, detailUrl(work.id), 'work-card-link'));
  }
  const visual = work.primary.type.startsWith('image/')
    ? galleryImage(work)
    : element('span', { class: `file-mark ${category.format}`, 'aria-hidden': 'true' },
      category.format === 'pdf' ? '𝄞' : '');
  return element('article', { class: 'work-card' },
    element('a', { class: 'work-card-link', href: detailUrl(work.id) },
      element('div', { class: 'work-cover' }, visual), copy));
}

function categoryLink(text, href, selected, className = 'tab') {
  return link(text, href, className, { 'aria-current': selected ? 'page' : null });
}

function addLink(category) {
  const href = category ? `${links.import}?category=${encodeURIComponent(category)}` : links.import;
  return link('ファイルを追加', href, 'button button-dark');
}

function normalizeSearch(text) {
  return text.normalize('NFKC').toLowerCase().replace(/[ァ-ヶ]/g, char => String.fromCharCode(char.charCodeAt(0) - 96));
}

async function renderCollection() {
  const music = page === 'music';
  const notes = music && params.get('view') === 'notes';
  const folder = folders.some(([key]) => key === params.get('folder')) ? params.get('folder') : '';
  const activeCategory = music ? (notes ? folder : 'score') : (params.get('category') === 'other-art' ? 'other-art' : 'illustration');
  const eligible = element('section', { class: 'collection-results', 'aria-label': '作品一覧' });
  const search = element('input', { type: 'search', placeholder: '作品名で検索', 'aria-label': '作品名で検索', maxlength: 200 });
  search.value = params.get('q') || '';
  const tabs = music ? [
    categoryLink('楽譜', links.music, !notes),
    categoryLink('練習メモ・資料', `${links.music}?view=notes`, notes),
  ] : [
    categoryLink('挿絵', links.art, activeCategory === 'illustration'),
    categoryLink('その他', `${links.art}?category=other-art`, activeCategory === 'other-art'),
  ];
  const toolbar = element('div', { class: 'toolbar' },
    element('nav', { class: 'tabs', 'aria-label': 'カテゴリ' }, ...tabs),
    element('div', { class: 'search-field' }, element('span', { 'aria-hidden': 'true', class: 'search-icon' }), search));
  main.append(pageHeading(music ? '音楽置き場' : 'イラスト置き場', music ? 'Music Archive' : 'Illustration Archive'), toolbar);
  main.append(eligible);
  eligible.append(element('p', { class: 'muted', role: 'status' }, '作品を読み込んでいます…'));

  const allWorks = await storage.listWorks();
  const matchesCategory = work => activeCategory
    ? work.category === activeCategory
    : folders.some(([key]) => work.category === key);
  const folderCounts = new Map();

  if (notes) {
    const folderSlides = folders.map(([key, category]) => {
      const itemCount = allWorks.filter(work => work.category === key).length;
      const href = key === folder ? `${links.music}?view=notes` : collectionUrl(key);
      const badge = element('span', { class: 'folder-count' }, `${itemCount}件`);
      folderCounts.set(key, badge);
      return element('a', { class: 'folder', href, 'aria-current': key === folder ? 'page' : null },
        element('span', { class: 'folder-icon', 'aria-hidden': 'true' }),
        element('span', {}, category.label), badge);
    });
    const folderCarousel = carousel(folderSlides, { id: 'folder-slides', label: '練習メモのフォルダ',
      className: 'folder-carousel', startAt: Math.max(0, folders.findIndex(([key]) => key === folder)) });
    eligible.before(folderCarousel.node);
  }

  const heading = element('h2', {}, activeCategory ? categories[activeCategory].label : 'すべての練習メモ・資料');
  const count = element('span', { class: 'result-count', role: 'status' });
  const content = element('div');
  let resultCarousel;
  let startAt = Math.max(0, (Number.parseInt(params.get('p'), 10) - 1) * 9 || 0);
  eligible.replaceChildren(element('div', { class: 'results-heading' }, heading, count), content);

  function syncUrl() {
    const url = new URL(location.href);
    if (search.value) url.searchParams.set('q', search.value);
    else url.searchParams.delete('q');
    url.searchParams.delete('p');
    history.replaceState(null, '', url);
  }

  function redraw(preserveScroll = false) {
    const previousScroll = preserveScroll ? content.querySelector('.carousel-viewport')?.scrollLeft : 0;
    resultCarousel?.dispose();
    resultCarousel = undefined;
    const tokens = normalizeSearch(search.value).trim().split(/\s+/).filter(Boolean);
    const results = allWorks.filter(work => matchesCategory(work) &&
      tokens.every(token => normalizeSearch(work.title).includes(token)));
    count.textContent = `${results.length}件`;
    if (!results.length) {
      if (tokens.length) {
        const reset = button('検索をクリア', { class: 'button button-light' });
        reset.addEventListener('click', () => {
          search.value = '';
          syncUrl();
          redraw();
          search.focus();
        });
        content.replaceChildren(notice('一致する作品がありません', '別の作品名を入力してください。', reset));
      } else {
        content.replaceChildren(notice('まだファイルがありません',
          '端末にあるファイルを追加すると、ここに並びます。', addLink(activeCategory || 'basics')));
      }
      return;
    }

    resultCarousel = carousel(results.map(workCard), { id: 'work-slides', label: '作品カード',
      className: 'work-carousel', startAt: Math.min(startAt, results.length - 1) });
    content.replaceChildren(resultCarousel.node);
    if (previousScroll) content.querySelector('.carousel-viewport').scrollLeft = previousScroll;
  }

  search.addEventListener('input', () => {
    syncUrl();
    redraw();
  });
  document.addEventListener('archive:restored', ({ detail: work }) => {
    if (allWorks.some(item => item.id === work.id)) return;
    allWorks.push(work);
    allWorks.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    const badge = folderCounts.get(work.category);
    if (badge) badge.textContent = `${allWorks.filter(item => item.category === work.category).length}件`;
    if (matchesCategory(work)) redraw(true);
  });
  redraw();
  startAt = 0;
}

function breadcrumb(text, href) {
  return element('nav', { class: 'breadcrumb', 'aria-label': '戻り先' }, link(text, href, 'text-link'));
}

function illustrationPreview(work, sources) {
  const flip = work.reverse ? flipIllustration(work, sources) : null;
  const image = flip?.control || element('img', { src: sources.primary, alt: work.title });
  const enlarge = button('拡大して見る', { class: 'button button-light', 'aria-haspopup': 'dialog' });
  const close = button('閉じる', { class: 'button button-dark' });
  const zoom = button('さらに拡大', { class: 'button button-light', 'aria-pressed': 'false' });
  const enlargedImage = element('img', { alt: work.title });
  const canvas = element('div', { class: 'zoom-canvas', tabindex: '0', 'aria-label': '拡大したイラスト' }, enlargedImage);
  const dialogTitle = element('span', { id: 'dialog-title' }, work.title);
  const dialog = element('dialog', { class: 'art-dialog', 'aria-labelledby': 'dialog-title' },
    element('div', { class: 'dialog-bar' }, dialogTitle,
      element('div', { class: 'actions' }, zoom, close)), canvas);
  enlarge.addEventListener('click', () => {
    const side = flip?.currentSide() ?? 'primary';
    const title = flip ? `${work.title}（${side === 'primary' ? '表面' : '裏面'}）` : work.title;
    dialogTitle.textContent = title;
    enlargedImage.alt = title;
    enlargedImage.src = sources[side];
    dialog.showModal();
  });
  close.addEventListener('click', () => dialog.close());
  dialog.addEventListener('click', event => {
    if (event.target === dialog) dialog.close();
  });
  zoom.addEventListener('click', () => {
    const active = canvas.classList.toggle('is-zoomed');
    zoom.setAttribute('aria-pressed', String(active));
    zoom.textContent = active ? '全体を表示' : 'さらに拡大';
  });
  dialog.addEventListener('close', () => {
    if (canvas.classList.contains('is-zoomed')) zoom.click();
    canvas.scrollTo(0, 0);
    enlarge.focus();
  });
  if (!flip) {
    image.addEventListener('error', () => image.replaceWith(element('p', {}, 'この画像を表示できません。ファイルをダウンロードして開いてください。')));
  }
  return [enlarge, element('div', { class: 'image-preview' }, image), dialog];
}

function audioPlayer(work, source) {
  const status = element('p', { class: 'muted', role: 'status', hidden: true });
  const player = element('audio', { controls: true, preload: 'metadata', src: source, 'aria-label': '作品の試聴' });
  player.addEventListener('error', () => {
    status.hidden = false;
    status.textContent = 'この形式を再生できません。音源をダウンロードして開いてください。';
  });
  return element('section', { class: 'audio-panel', 'aria-labelledby': 'listen-title' },
    element('h2', { id: 'listen-title' }, '試聴'), player, status,
    link('音源をダウンロード', source, 'text-link', { download: work.audio.name }));
}

function pdfPreview(work, source) {
  const canvas = element('canvas', { 'aria-label': `${work.title}のPDFプレビュー`, role: 'img' });
  const previous = button('前のページ', { class: 'button button-light', disabled: true });
  const next = button('次のページ', { class: 'button button-light', disabled: true });
  const count = element('span', { class: 'result-count', role: 'status' });
  const tools = element('div', { class: 'pdf-tools', hidden: true }, previous, count, next);
  const message = element('p', { class: 'muted pdf-message', role: 'status' }, 'PDFを読み込んでいます…');
  const sheet = element('div', { class: 'pdf-sheet', hidden: true }, canvas);
  const panel = element('div', { class: 'pdf-panel' }, tools, message, sheet);

  async function loadPdf() {
    const root = new URL('./pdfjs/', location.href).href;
    const pdfjs = await import(`${root}pdf.min.mjs`);
    pdfjs.GlobalWorkerOptions.workerSrc = `${root}pdf.worker.min.mjs`;
    const document = await pdfjs.getDocument({
      url: source,
      cMapUrl: `${root}cmaps/`, cMapPacked: true,
      standardFontDataUrl: `${root}standard_fonts/`,
      iccUrl: `${root}iccs/`, wasmUrl: `${root}wasm/`,
    }).promise;
    let current = 1;

    async function draw(number) {
      previous.disabled = next.disabled = true;
      const page = await document.getPage(number);
      const raw = page.getViewport({ scale: 1 });
      const viewport = page.getViewport({ scale: Math.min(2, 2300 / Math.max(raw.width, raw.height)) });
      canvas.width = Math.ceil(viewport.width);
      canvas.height = Math.ceil(viewport.height);
      await page.render({ canvas, viewport }).promise;
      current = number;
      count.textContent = `${current} / ${document.numPages}`;
      previous.disabled = current === 1;
      next.disabled = current === document.numPages;
      tools.hidden = false;
      sheet.hidden = false;
      message.hidden = true;
    }

    function failed() {
      message.hidden = false;
      message.textContent = 'プレビューを表示できません。上のボタンで開くか、ダウンロードしてください。';
    }

    previous.addEventListener('click', () => draw(current - 1).catch(failed));
    next.addEventListener('click', () => draw(current + 1).catch(failed));
    await draw(1);
  }

  loadPdf().catch(() => {
    message.textContent = 'プレビューを表示できません。上のボタンで開くか、ダウンロードしてください。';
  });
  return panel;
}

function metadataFields(work) {
  const title = element('input', { id: 'display-title', name: 'title', type: 'text', maxlength: titleLimit,
    placeholder: '空欄の場合はファイル名を使用' });
  const memo = element('textarea', { id: 'work-memo', name: 'memo', rows: 3, maxlength: memoLimit });
  title.value = work?.title ?? '';
  memo.value = work?.memo ?? '';
  const nameLabel = work ? '表示名' : '表示名（任意）';
  const memoLabel = work ? 'メモ' : 'メモ（任意）';
  return {
    inputs: { title, memo },
    rows: [
      element('div', { class: 'form-field' }, element('label', { for: title.id, class: 'form-label' }, nameLabel), title),
      element('div', { class: 'form-field' }, element('label', { for: memo.id, class: 'form-label' }, memoLabel), memo),
    ],
  };
}

function metadataEditor(work, showTitle) {
  const { inputs, rows } = metadataFields(work);
  const status = element('p', { class: 'form-status', role: 'status' }, '入力すると自動保存されます。');
  const saveButton = button('今すぐ保存', { type: 'submit', class: 'button button-light', disabled: true });
  const form = element('form', { class: 'metadata-form' },
    ...rows, element('div', { class: 'actions form-actions' }, saveButton, status));
  const keys = Object.keys(inputs);
  let saved = { title: work.title, memo: work.memo ?? '' };
  let inFlight;
  let timer;
  const editsSince = values => Object.fromEntries(keys.filter(key => inputs[key].value !== values[key])
    .map(key => [key, inputs[key].value]));

  async function save() {
    clearTimeout(timer);
    if (inFlight) return;
    const changes = editsSince(saved);
    if (!Object.keys(changes).length) {
      saveButton.disabled = true;
      status.textContent = '入力すると自動保存されます。';
      return;
    }
    inFlight = { ...saved, ...changes };
    saveButton.disabled = true;
    status.textContent = '保存中…';
    let success = false;
    try {
      const update = await storage.editWork(work.id, changes);
      for (const key of keys) {
        if (inputs[key].value === inFlight[key]) inputs[key].value = update[key] ?? '';
      }
      saved = { title: update.title, memo: update.memo ?? '' };
      Object.assign(work, saved);
      showTitle(saved.title);
      status.textContent = '保存しました';
      success = true;
    } catch (error) {
      status.textContent = `保存できませんでした。${storage.failureMessage(error)}`;
    } finally {
      inFlight = undefined;
      const pending = Object.keys(editsSince(saved)).length > 0;
      saveButton.disabled = !pending;
      if (success && pending) save();
    }
  }

  function scheduleSave() {
    clearTimeout(timer);
    const pending = Object.keys(editsSince(inFlight || saved)).length > 0;
    saveButton.disabled = !pending || Boolean(inFlight);
    if (inFlight) return;
    status.textContent = pending ? '変更を自動保存します…' : '入力すると自動保存されます。';
    if (pending) timer = setTimeout(save, 600);
  }

  form.addEventListener('compositionstart', () => clearTimeout(timer));
  form.addEventListener('compositionend', scheduleSave);
  form.addEventListener('input', event => {
    if (!event.isComposing) scheduleSave();
  });
  form.addEventListener('submit', event => {
    event.preventDefault();
    save();
  });
  window.addEventListener('pagehide', () => {
    if (!inFlight && Object.keys(editsSince(saved)).length) save();
  });
  window.addEventListener('beforeunload', event => {
    if (!inFlight && !Object.keys(editsSince(saved)).length) return;
    event.preventDefault();
    event.returnValue = '';
  });
  return element('details', { class: 'work-metadata' }, element('summary', {}, '表示名・メモを編集'), form);
}

async function renderWork() {
  const work = await storage.getWork(params.get('id') || '-');
  const category = categories[work.category];
  const mediaKinds = ['primary', 'audio', 'reverse'].filter(kind => work[kind]);
  const sources = Object.fromEntries(await Promise.all(mediaKinds.map(async kind => [kind, await mediaSource(work, kind)])));
  const destination = collectionUrl(work.category);
  renderHeader(category.collection);
  const heading = pageHeading(work.title, category.label, `追加日 ${dateFormat.format(new Date(work.createdAt))}`);
  function showTitle(title) {
    heading.querySelector('h1').textContent = title;
    document.title = `${title} | 間宵の創作室`;
  }
  showTitle(work.title);
  const workView = element('div', {}, heading);
  if (params.has('added')) {
    workView.append(element('p', { class: 'muted trash-status', role: 'status' }, '作品を追加しました。'));
    history.replaceState(null, '', detailUrl(work.id));
  }
  workView.append(metadataEditor(work, showTitle));
  const movedNotice = notice('作品をゴミ箱に移動しました', 'ゴミ箱で作品を管理できます。',
    link('作品一覧に戻る', destination, 'button button-light'));
  movedNotice.hidden = true;
  main.append(breadcrumb(`${category.collection === 'music' ? '音楽置き場' : 'イラスト置き場'} / ${category.label}`, destination),
    workView, movedNotice);
  const downloadLabel = work.primary.type === 'application/pdf' ? 'PDFをダウンロード' :
    work.reverse ? '表面をダウンロード' : category.format === 'image' ? '画像をダウンロード' : 'ファイルをダウンロード';
  const download = link(downloadLabel, sources.primary, 'button button-dark', { download: work.primary.name });
  const actions = element('div', { class: 'actions work-actions' });
  const preview = element('section', { class: 'work-preview', 'aria-label': '作品のプレビュー' });
  if (category.format === 'image') {
    const [enlarge, image, dialog] = illustrationPreview(work, sources);
    actions.append(enlarge);
    preview.append(image, dialog);
  } else if (work.primary.type === 'application/pdf') {
    actions.append(link('PDFを別タブで開く', sources.primary, 'button button-light', { target: '_blank', rel: 'noopener' }));
    preview.append(pdfPreview(work, sources.primary));
  } else {
    const { file } = await storage.getMedia(work.id, 'primary');
    const contents = await file.arrayBuffer();
    let text;
    try {
      text = new TextDecoder('utf-8', { fatal: true }).decode(contents);
    } catch {
      text = new TextDecoder('shift_jis').decode(contents);
    }
    preview.append(element('pre', { class: 'note-preview' }, text));
  }
  actions.append(download);
  if (work.reverse) {
    actions.append(link('裏面をダウンロード', sources.reverse, 'button button-light', { download: work.reverse.name }));
  }
  actions.append(confirmedAction('ゴミ箱に移動', {
    title: '作品をゴミ箱に移動しますか？',
    message: `「${work.title}」は作品一覧から取り下げられます。ゴミ箱から復元できます。`,
    confirmLabel: 'ゴミ箱に移動',
    perform: () => storage.moveWork(work.id, true),
    afterSuccess() {
      workView.querySelector('audio')?.pause();
      workView.hidden = true;
      movedNotice.hidden = false;
      openTrash('作品をゴミ箱に移動しました。');
    },
  }));
  workView.append(actions);
  if (work.audio) workView.append(audioPlayer(work, sources.audio));
  workView.append(preview);
  document.addEventListener('archive:restored', ({ detail: restored }) => {
    if (restored.id !== work.id) return;
    workView.hidden = false;
    movedNotice.hidden = true;
  });
  document.addEventListener('archive:purged', ({ detail: id }) => {
    if (id !== work.id) return;
    for (const source of Object.values(sources)) URL.revokeObjectURL(source);
    workView.remove();
  });
}

function openTrash(message = '') {
  if (document.querySelector('#trash-dialog[open]')) return;
  const close = button('閉じる', { class: 'button button-light' });
  const heading = element('header', { class: 'trash-dialog-heading' },
    element('h2', { id: 'trash-dialog-title' }, 'ゴミ箱'), close);
  const content = element('div', { class: 'trash-dialog-content' });
  const dialog = element('dialog', { id: 'trash-dialog', class: 'trash-dialog', 'aria-labelledby': 'trash-dialog-title' }, heading, content);
  close.addEventListener('click', () => dialog.close());
  dialog.addEventListener('close', () => dialog.remove(), { once: true });
  document.body.append(dialog);
  dialog.showModal();
  close.focus();
  renderTrashContents(content, message);
}

async function renderTrashContents(container, message = '') {
  const status = element('p', { class: 'muted trash-status', role: 'status' }, message);
  const results = element('div', {}, element('p', { class: 'muted', role: 'status' }, 'ゴミ箱を読み込んでいます…'));
  container.replaceChildren(status, results);

  let works;
  try {
    works = await storage.listWorks(true);
  } catch (error) {
    const retry = button('再読み込み', { class: 'button button-light' });
    retry.addEventListener('click', () => renderTrashContents(container, message));
    results.replaceChildren(notice('ゴミ箱を読み込めませんでした', storage.failureMessage(error), retry));
    return;
  }

  const list = element('ul', { class: 'trash-list', 'aria-label': 'ゴミ箱の作品' });
  function showEmpty() {
    results.replaceChildren(notice('ゴミ箱は空です', '削除した作品がここに表示されます。'));
  }
  function removeFromList(row, message) {
    row.remove();
    if (!list.children.length) showEmpty();
    status.textContent = message;
  }

  for (const work of works) {
    const title = element('h2', {}, work.title);
    const category = categories[work.category].label;
    const details = element('div', {}, title,
      element('p', { class: 'muted' }, work.reverse ? `${category} · 表面と裏面` : category));
    const restore = button('復元', { class: 'button button-light', 'aria-label': `「${work.title}」を復元` });
    const purge = confirmedAction('完全に削除', {
      title: '作品を完全に削除しますか？',
      message: `「${work.title}」の登録データを完全に削除します。この操作は取り消せません。`,
      confirmLabel: '完全に削除',
      async perform() {
        await storage.purgeWork(work.id);
        removeFromList(row, '作品を完全に削除しました。');
        document.dispatchEvent(new CustomEvent('archive:purged', { detail: work.id }));
      },
    }, { 'aria-label': `「${work.title}」を完全に削除` });
    const row = element('li', { class: 'trash-work' }, details, element('div', { class: 'actions' }, restore, purge));
    restore.addEventListener('click', async () => {
      restore.disabled = purge.disabled = true;
      try {
        const restored = await storage.moveWork(work.id, false);
        removeFromList(row, '作品を復元しました。');
        document.dispatchEvent(new CustomEvent('archive:restored', { detail: restored }));
      } catch (error) {
        status.textContent = storage.failureMessage(error);
        restore.disabled = purge.disabled = false;
      }
    });
    list.append(row);
  }
  if (works.length) results.replaceChildren(list);
  else showEmpty();
}

async function renderTrash() {
  const content = element('div');
  main.append(pageHeading('ゴミ箱', 'Trash'), content);
  await renderTrashContents(content, params.has('moved') ? '作品をゴミ箱に移動しました。' : '');
}

function fileInput(label, name, required) {
  const input = element('input', { type: 'file', id: name, name, class: 'file-input', required });
  const labelText = element('span', { class: 'file-label' }, 'ファイルを選ぶ');
  const hint = element('p', { class: 'muted file-hint', id: `${name}-types` });
  const zone = element('label', { class: 'drop-zone', for: name }, input,
    element('span', { class: 'button button-light file-trigger' }, labelText),
    element('span', { class: 'drop-caption' }, 'または、ここにドロップ'));
  input.setAttribute('aria-describedby', hint.id);
  input.setAttribute('aria-label', label);
  input.addEventListener('change', () => {
    labelText.textContent = input.files[0]?.name || 'ファイルを選ぶ';
  });
  zone.addEventListener('dragover', event => {
    event.preventDefault();
    zone.classList.add('is-dragging');
  });
  zone.addEventListener('dragleave', () => zone.classList.remove('is-dragging'));
  zone.addEventListener('drop', event => {
    event.preventDefault();
    zone.classList.remove('is-dragging');
    const file = event.dataTransfer.files[0];
    if (!file || input.disabled) return;
    const transfer = new DataTransfer();
    transfer.items.add(file);
    input.files = transfer.files;
    input.dispatchEvent(new Event('change'));
  });
  const heading = element('p', { class: 'form-label' }, label);
  function setLabel(text) {
    heading.textContent = text;
    input.setAttribute('aria-label', text);
  }
  return { input, hint, setLabel, wrapper: element('div', { class: 'form-field' }, heading, zone, hint) };
}

function renderImport() {
  const select = element('select', { id: 'category', name: 'category', required: true });
  for (const [collection, label] of [['music', '音楽置き場'], ['art', 'イラスト置き場']]) {
    const items = Object.entries(categories).filter(([, category]) => category.collection === collection);
    select.append(element('optgroup', { label }, ...items.map(([key, category]) => element('option', { value: key }, category.label))));
  }
  if (Object.hasOwn(categories, params.get('category'))) select.value = params.get('category');
  const primary = fileInput('作品ファイル', 'file', true);
  const audio = fileInput('試聴音源（任意）', 'audio', false);
  const reverse = fileInput('裏面の画像（任意）', 'reverse', false);
  audio.input.accept = Object.keys(formats.audio).join(',');
  audio.hint.textContent = 'MP3、WAV、M4A、AAC、OGG、FLAC';
  reverse.input.accept = Object.keys(formats.image).join(',');
  reverse.hint.textContent = '表面と裏面は1つの作品として登録されます。';

  function updateFormat() {
    const { format } = categories[select.value];
    const isIllustration = format === 'image';
    primary.setLabel(isIllustration ? '表面の画像' : '作品ファイル');
    primary.input.accept = Object.keys(formats[format]).join(',');
    const descriptions = { pdf: 'PDF', image: 'JPEG、PNG、WebP、GIF、AVIF', note: 'TXT、Markdown、PDF' };
    primary.hint.textContent = descriptions[format];
    const withAudio = select.value === 'score';
    audio.wrapper.hidden = !withAudio;
    audio.input.disabled = !withAudio;
    reverse.wrapper.hidden = !isIllustration;
    reverse.input.disabled = !isIllustration;
  }

  const status = element('p', { class: 'form-status', role: 'status' });
  const submit = button('アーカイブに追加', { type: 'submit', class: 'button button-dark' });
  const { rows } = metadataFields();
  const form = element('form', { class: 'import-form' },
    element('div', { class: 'form-field' }, element('label', { for: 'category', class: 'form-label' }, '追加先'), select),
    ...rows, primary.wrapper, reverse.wrapper, audio.wrapper,
    element('p', { class: 'muted limit-note' }, 'ファイルは1回につき合計150 MBまで。'),
    element('div', { class: 'actions form-actions' }, submit, status));
  select.addEventListener('change', updateFormat);
  updateFormat();

  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (submit.disabled) return;
    submit.disabled = true;
    form.setAttribute('aria-busy', 'true');
    status.textContent = '追加しています…';
    try {
      const work = await storage.addWork(new FormData(form));
      location.assign(`${detailUrl(work.id)}&added=1`);
    } catch (error) {
      status.textContent = storage.failureMessage(error);
      form.removeAttribute('aria-busy');
      submit.disabled = false;
    }
  });
  main.append(pageHeading('ファイルを追加', 'Import Files', '追加した作品やメモは、このブラウザーに保存されます。'), form);
}

async function init() {
  renderHeader();
  renderFooter();
  try {
    if (page === 'home') await renderHome();
    else if (page === 'work') await renderWork();
    else if (page === 'import') renderImport();
    else if (page === 'trash') await renderTrash();
    else await renderCollection();
  } catch (error) {
    const message = notice('読み込めませんでした', error.message, link('ホームに戻る', links.home, 'button button-light'));
    if (page !== 'home') main.replaceChildren(message);
    else main.append(message);
  }
}

init();

window.addEventListener('pageshow', event => {
  if (event.persisted && (page === 'music' || page === 'art')) location.reload();
});
