window.archiveReady = (async () => {
  if (!('serviceWorker' in navigator) || !('indexedDB' in window)) {
    throw new Error('ブラウザーの保存機能を使える状態で開いてください。');
  }
  await navigator.serviceWorker.register('./archive-worker.js', { scope: './', updateViaCache: 'none' });
  await Promise.race([
    navigator.serviceWorker.ready.then(() => {
      if (navigator.serviceWorker.controller) return;
      return new Promise(resolve => navigator.serviceWorker.addEventListener('controllerchange', resolve, { once: true }));
    }),
    new Promise((_, reject) => setTimeout(() => reject(new Error('ページを再読み込みしてください。')), 10000)),
  ]);
})();
