importScripts('./catalog.js');

const { categories, formats, maxBytes, titleLimit, memoLimit } = self.archiveCatalog;
const scope = new URL(self.registration.scope);
const idPattern = /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/;
let database;

self.addEventListener('install', event => event.waitUntil(self.skipWaiting()));
self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  const prefix = `${scope.pathname}api/`;
  if (url.origin === scope.origin && url.pathname.startsWith(prefix)) {
    event.respondWith(handleApi(event.request, url.pathname.slice(prefix.length), url.searchParams));
  }
});

class ApiError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

function resultOf(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function openDatabase() {
  if (!database) {
    const open = indexedDB.open(`creative-archive:${scope.pathname}`, 1);
    open.onupgradeneeded = () => {
      open.result.createObjectStore('works', { keyPath: 'id' });
      open.result.createObjectStore('media');
    };
    database = resultOf(open).then(db => {
      db.onversionchange = () => {
        db.close();
        database = undefined;
      };
      return db;
    }).catch(error => {
      database = undefined;
      throw error;
    });
  }
  return database;
}

async function transaction(stores, mode, perform) {
  const tx = (await openDatabase()).transaction(stores, mode);
  const complete = new Promise((resolve, reject) => {
    tx.oncomplete = resolve;
    tx.onabort = () => reject(tx.error || new Error('保存処理が中断されました。'));
  });
  try {
    const value = await perform(tx);
    await complete;
    return value;
  } catch (error) {
    try { tx.abort(); } catch { /* The transaction may already be closed. */ }
    await complete.catch(() => {});
    throw error;
  }
}

function metadata(work) {
  const { trashed, ...item } = work;
  return item;
}

function readWork(store, id, trashed = false) {
  return resultOf(store.get(id)).then(work => {
    if (!work || work.trashed !== trashed) throw new ApiError(404, '作品が見つかりません。');
    return work;
  });
}

function titleOf(value, file) {
  if (typeof value !== 'string' || value.length > titleLimit || /[\r\n]/.test(value)) {
    throw new ApiError(400, `表示名は${titleLimit}文字以内で入力してください。`);
  }
  return value.trim() || file.name.slice(0, -file.ext.length).trim() || file.name;
}

function memoOf(value) {
  const memo = typeof value === 'string' ? value.replace(/\r\n?/g, '\n') : null;
  if (memo === null || memo.length > memoLimit) throw new ApiError(400, `メモは${memoLimit}文字以内で入力してください。`);
  return memo;
}

function fileInfo(file, format, label) {
  const name = file instanceof File ? file.name.split(/[\\/]/).pop().replace(/[\r\n]/g, '') : '';
  const ext = /\.[^.]+$/.exec(name)?.[0].toLowerCase();
  const type = formats[format][ext];
  if (!file?.size || !type) throw new ApiError(400, `${label}の形式を確認してください。`);
  return { name, ext, type };
}

async function addWork(request) {
  let form;
  try { form = await request.formData(); } catch { throw new ApiError(400, 'ファイルを選んでください。'); }
  const category = form.get('category');
  if (typeof category !== 'string' || !Object.hasOwn(categories, category)) throw new ApiError(400, '追加先を選んでください。');
  const { format } = categories[category];
  const primaryFile = form.get('file');
  const audioFile = form.get('audio');
  const reverseFile = form.get('reverse');
  const primary = fileInfo(primaryFile, format, '作品ファイル');
  if (audioFile?.size && category !== 'score') throw new ApiError(400, '試聴音源は楽譜に追加できます。');
  if (reverseFile?.size && format !== 'image') throw new ApiError(400, '裏面の画像はイラストに追加できます。');
  const audio = audioFile?.size ? fileInfo(audioFile, 'audio', '試聴音源') : null;
  const reverse = reverseFile?.size ? fileInfo(reverseFile, 'image', '裏面の画像') : null;
  if (primaryFile.size + (audioFile?.size || 0) + (reverseFile?.size || 0) > maxBytes) {
    throw new ApiError(413, 'ファイルの合計は150 MBまでです。');
  }
  const id = crypto.randomUUID();
  const work = { id, category, title: titleOf(form.get('title') ?? '', primary), memo: memoOf(form.get('memo') ?? ''),
    primary, audio, reverse, createdAt: new Date().toISOString(), trashed: false };
  return transaction(['works', 'media'], 'readwrite', async tx => {
    tx.objectStore('works').add(work);
    const media = tx.objectStore('media');
    media.add(primaryFile, [id, 'primary']);
    if (audio) media.add(audioFile, [id, 'audio']);
    if (reverse) media.add(reverseFile, [id, 'reverse']);
    return metadata(work);
  });
}

async function editWork(request, id) {
  let fields;
  try { fields = await request.json(); } catch { throw new ApiError(400, '保存する内容を確認してください。'); }
  if (!fields || typeof fields !== 'object' || !Object.keys(fields).length ||
      Object.keys(fields).some(key => !['title', 'memo'].includes(key))) {
    throw new ApiError(400, '保存する内容を確認してください。');
  }
  return transaction('works', 'readwrite', async tx => {
    const store = tx.objectStore('works');
    const work = await readWork(store, id);
    if (Object.hasOwn(fields, 'title')) work.title = titleOf(fields.title, work.primary);
    if (Object.hasOwn(fields, 'memo')) work.memo = memoOf(fields.memo);
    store.put(work);
    return metadata(work);
  });
}

function moveWork(id, toTrash) {
  return transaction('works', 'readwrite', async tx => {
    const store = tx.objectStore('works');
    const work = await readWork(store, id, !toTrash);
    work.trashed = toTrash;
    store.put(work);
    return metadata(work);
  });
}

function purgeWork(id) {
  return transaction(['works', 'media'], 'readwrite', async tx => {
    const works = tx.objectStore('works');
    const work = await readWork(works, id, true);
    const media = tx.objectStore('media');
    for (const kind of ['primary', 'audio', 'reverse']) if (work[kind]) media.delete([id, kind]);
    works.delete(id);
    return { id };
  });
}

function listWorks(trashed) {
  return transaction('works', 'readonly', async tx => {
    const works = await resultOf(tx.objectStore('works').getAll());
    return works.filter(work => work.trashed === trashed).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).map(metadata);
  });
}

async function serveMedia(request, id, kind, download) {
  const { info, file } = await transaction(['works', 'media'], 'readonly', async tx => {
    const work = await readWork(tx.objectStore('works'), id);
    const file = work[kind] && await resultOf(tx.objectStore('media').get([id, kind]));
    if (!file) throw new ApiError(404, 'ファイルが見つかりません。');
    return { info: work[kind], file };
  });
  const headers = { 'Content-Type': info.type === 'text/plain' ? 'text/plain; charset=utf-8' : info.type,
    'Accept-Ranges': 'bytes', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' };
  if (download) {
    const filename = encodeURIComponent(info.name).replace(/['()*]/g, char => `%${char.charCodeAt(0).toString(16)}`);
    headers['Content-Disposition'] = `attachment; filename*=UTF-8''${filename}`;
  }
  let start = 0;
  let end = file.size - 1;
  let status = 200;
  const range = /^bytes=(\d*)-(\d*)$/.exec(request.headers.get('Range') || '');
  if (range && (range[1] || range[2])) {
    if (range[1]) {
      start = Number(range[1]);
      if (range[2]) end = Math.min(end, Number(range[2]));
    } else {
      start = Math.max(0, file.size - Number(range[2]));
    }
    if (start >= file.size || start > end) return new Response(null, { status: 416, headers: { 'Content-Range': `bytes */${file.size}` } });
    status = 206;
    headers['Content-Range'] = `bytes ${start}-${end}/${file.size}`;
  }
  headers['Content-Length'] = end - start + 1;
  return new Response(request.method === 'HEAD' ? null : file.slice(start, end + 1), { status, headers });
}

async function handleApi(request, path, params) {
  const { method } = request;
  try {
    if (path === 'links' && method === 'GET') return await fetch(new URL('links.json', scope));
    if (path === 'works' && method === 'GET') return Response.json(await listWorks(false));
    if (path === 'works' && method === 'POST') return Response.json(await addWork(request), { status: 201 });
    if (path === 'trash' && method === 'GET') return Response.json(await listWorks(true));
    const [group, id, kind, extra] = path.split('/');
    if (extra !== undefined || !idPattern.test(id || '')) throw new ApiError(404, '作品が見つかりません。');
    if (group === 'works') {
      if (['primary', 'reverse', 'audio'].includes(kind) && ['GET', 'HEAD'].includes(method)) {
        return await serveMedia(request, id, kind, params.has('download'));
      }
      if (!kind && method === 'GET') return Response.json(await transaction('works', 'readonly', async tx => metadata(await readWork(tx.objectStore('works'), id))));
      if (!kind && method === 'PATCH') return Response.json(await editWork(request, id));
      if (!kind && method === 'DELETE') return Response.json(await moveWork(id, true));
    }
    if (group === 'trash' && !kind && method === 'POST') return Response.json(await moveWork(id, false));
    if (group === 'trash' && !kind && method === 'DELETE') return Response.json(await purgeWork(id));
    throw new ApiError(404, 'ページが見つかりません。');
  } catch (error) {
    const message = error.status ? error.message : error.name === 'QuotaExceededError'
      ? 'ブラウザーの保存容量が足りません。' : '処理できませんでした。ページを再読み込みしてお試しください。';
    return Response.json({ message }, { status: error.status || 500 });
  }
}
