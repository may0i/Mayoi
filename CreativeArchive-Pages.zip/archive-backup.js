(function () {
  const { categories, formats, maxBytes, titleLimit, memoLimit } = window.archiveCatalog;
  const storage = window.archiveStorage;
  const zip = window.zip;
  const mediaKinds = ['primary', 'audio', 'reverse'];
  const idPattern = /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/;
  const manifestPath = 'archive.json';
  const manifestLimit = 16 * 1024 * 1024;
  const format = 'creative-archive';
  const version = 1;

  class BackupError extends Error {}

  function invalidBackup() {
    return new BackupError('間宵の創作室から書き出したZIPを選んでください。ファイルが破損している可能性もあります。');
  }

  function mediaPath(work, kind) {
    return 'works/' + work.id + '/' + kind + work[kind].ext;
  }

  async function createZip() {
    const records = await storage.readBackup();
    if (!records.length) throw new BackupError('バックアップする作品がありません。');
    const manifest = new Blob([JSON.stringify({ format, version, works: records.map(({ work }) => work) })]);
    if (manifest.size > manifestLimit) throw new BackupError('作品情報が多すぎるため、ZIPを作成できませんでした。');
    const writer = new zip.ZipWriter(new zip.BlobWriter('application/zip'), { level: 0 });
    try {
      await writer.add(manifestPath, new zip.BlobReader(manifest));
      for (const { work, files } of records) {
        for (const [kind, file] of Object.entries(files)) {
          await writer.add(mediaPath(work, kind), new zip.BlobReader(file));
        }
      }
      return await writer.close();
    } catch (error) {
      await writer.close().catch(() => {});
      throw error;
    }
  }

  function parseFile(value, allowedFormats) {
    if (!allowedFormats || typeof value?.name !== 'string') throw invalidBackup();
    const ext = /\.[^.]+$/.exec(value.name)?.[0].toLowerCase();
    const type = allowedFormats[ext];
    if (!type || value.ext !== ext || value.type !== type) throw invalidBackup();
    return { name: value.name, ext, type };
  }

  function parseWork(value) {
    if (typeof value?.id !== 'string' || !idPattern.test(value.id) ||
        !Object.hasOwn(categories, value.category) || typeof value.trashed !== 'boolean' ||
        typeof value.createdAt !== 'string' || Number.isNaN(Date.parse(value.createdAt)) ||
        typeof value.title !== 'string' || typeof value.memo !== 'string' || value.memo.length > memoLimit) {
      throw invalidBackup();
    }
    const { id, category, title, memo, createdAt, trashed } = value;
    const { format: primaryFormat } = categories[category];
    const primary = parseFile(value.primary, formats[primaryFormat]);
    const fallbackTitle = primary.name.slice(0, -primary.ext.length).trim() || primary.name;
    if (!title || (title !== fallbackTitle && (title.length > titleLimit || /[\r\n]/.test(title)))) {
      throw invalidBackup();
    }
    const audio = value.audio === null ? null : parseFile(value.audio, category === 'score' && formats.audio);
    const reverse = value.reverse === null ? null : parseFile(value.reverse, primaryFormat === 'image' && formats.image);
    return { id, category, title, memo, primary, audio, reverse, createdAt, trashed };
  }

  async function readZip(file) {
    const reader = new zip.ZipReader(new zip.BlobReader(file), {
      checkSignature: true, checkOverlappingEntry: true, strictness: 'strict',
    });
    try {
      const entries = new Map();
      const zipEntries = await reader.getEntries();
      if (!zipEntries.some(entry => entry.filename === manifestPath)) {
        throw new BackupError('このアプリで作成したバックアップZIPを選んでください。通常のZIPは展開して作品ファイルを追加できます。');
      }
      for (const entry of zipEntries) {
        // Backups use stored entries so restoring them cannot inflate the input.
        if (entry.directory || entry.encrypted || entry.compressionMethod !== 0 ||
            entry.compressedSize !== entry.uncompressedSize || entries.has(entry.filename)) {
          throw invalidBackup();
        }
        entries.set(entry.filename, entry);
      }
      const manifest = entries.get(manifestPath);
      if (!manifest || manifest.uncompressedSize > manifestLimit) throw invalidBackup();
      entries.delete(manifestPath);
      const data = JSON.parse(await manifest.getData(new zip.TextWriter()));
      if (data?.format !== format || data.version !== version || !Array.isArray(data.works) || !data.works.length) {
        throw invalidBackup();
      }
      const ids = new Set();
      const records = [];
      for (const value of data.works) {
        const work = parseWork(value);
        if (ids.has(work.id)) throw invalidBackup();
        ids.add(work.id);
        const files = {};
        let totalBytes = 0;
        for (const kind of mediaKinds) {
          if (!work[kind]) continue;
          const path = mediaPath(work, kind);
          const entry = entries.get(path);
          if (!entry || !entry.uncompressedSize) throw invalidBackup();
          totalBytes += entry.uncompressedSize;
          if (totalBytes > maxBytes) throw invalidBackup();
          files[kind] = await entry.getData(new zip.BlobWriter(work[kind].type));
          entries.delete(path);
        }
        records.push({ work, files });
      }
      if (entries.size) throw invalidBackup();
      return records;
    } catch (error) {
      if (error instanceof BackupError) throw error;
      throw invalidBackup();
    } finally {
      await reader.close();
    }
  }

  const panel = document.querySelector('#backup-template').content.firstElementChild.cloneNode(true);
  const exportButton = panel.querySelector('#backup-export');
  const download = panel.querySelector('#backup-download');
  const dropZone = panel.querySelector('#backup-drop');
  const input = panel.querySelector('#backup-file');
  const update = panel.querySelector('#backup-update');
  const status = panel.querySelector('#backup-status');
  document.querySelector('#main').append(panel);

  let downloadUrl;
  async function run(message, perform) {
    exportButton.disabled = true;
    input.disabled = true;
    update.disabled = true;
    dropZone.setAttribute('aria-disabled', 'true');
    status.textContent = message;
    try {
      if (!zip) throw new BackupError('ZIP機能を読み込めませんでした。ページを再読み込みしてください。');
      zip.configure({ useWebWorkers: false });
      await perform();
    } catch (error) {
      status.textContent = error instanceof BackupError ? error.message : storage.failureMessage(error);
    } finally {
      exportButton.disabled = false;
      input.disabled = false;
      update.disabled = false;
      dropZone.removeAttribute('aria-disabled');
    }
  }

  exportButton.addEventListener('click', () => {
    run('ZIPを作成しています…', async () => {
      const file = await createZip();
      if (downloadUrl) URL.revokeObjectURL(downloadUrl);
      downloadUrl = URL.createObjectURL(file);
      download.href = downloadUrl;
      download.download = 'CreativeArchive-' + new Date().toISOString().slice(0, 10) + '.zip';
      download.hidden = false;
      download.click();
      status.textContent = 'バックアップZIPを作成しました。';
    });
  });

  function restore(file) {
    const replaceExisting = update.checked;
    run('ZIPを読み込んでいます…', async () => {
      const { restored, updated, skipped } = await storage.restoreBackup(await readZip(file), replaceExisting);
      const messages = [restored + '件を復元しました。'];
      if (updated) messages.push(updated + '件をZIPの内容で上書きしました。');
      if (skipped) messages.push('登録済みの' + skipped + '件はそのままです。');
      status.textContent = messages.join(' ');
      update.checked = false;
    });
  }

  input.addEventListener('change', () => {
    const file = input.files[0];
    input.value = '';
    if (file) restore(file);
  });
  dropZone.addEventListener('dragover', event => {
    event.preventDefault();
    if (input.disabled) return;
    event.dataTransfer.dropEffect = 'copy';
    dropZone.classList.add('is-dragging');
  });
  dropZone.addEventListener('dragleave', event => {
    if (!dropZone.contains(event.relatedTarget)) dropZone.classList.remove('is-dragging');
  });
  dropZone.addEventListener('drop', event => {
    event.preventDefault();
    dropZone.classList.remove('is-dragging');
    if (input.disabled) return;
    const files = event.dataTransfer.files;
    if (files.length === 1) restore(files[0]);
    else status.textContent = 'バックアップZIPを1つ選んでください。';
  });
})();
