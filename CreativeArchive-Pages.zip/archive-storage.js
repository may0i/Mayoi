(function (runtime) {
  const { categories, formats, maxBytes, titleLimit, memoLimit } = runtime.archiveCatalog;
  const archivePath = new URL('./', runtime.location.href).pathname;
  let database;

  class StorageError extends Error {
    constructor(status, message) {
      super(message);
      this.status = status;
    }
  }

  function resultOf(request) {
    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  function openDatabase() {
    if (!database) {
      database = Promise.resolve().then(() => {
        if (!runtime.indexedDB) throw new StorageError(503, 'このブラウザーでは作品を保存できません。');
        const request = runtime.indexedDB.open(`creative-archive:${archivePath}`, 1);
        request.onupgradeneeded = () => {
          request.result.createObjectStore('works', { keyPath: 'id' });
          request.result.createObjectStore('media');
        };
        return resultOf(request);
      }).then(db => {
        db.onversionchange = () => {
          db.close();
          database = undefined;
        };
        return db;
      }).catch(error => {
        database = undefined;
        throw error;
      });
    }
    return database;
  }

  async function transaction(stores, mode, perform) {
    const tx = (await openDatabase()).transaction(stores, mode);
    const complete = new Promise((resolve, reject) => {
      tx.oncomplete = resolve;
      tx.onabort = () => reject(tx.error || new Error('保存処理が中断されました。'));
    });
    try {
      const value = await perform(tx);
      await complete;
      return value;
    } catch (error) {
      try { tx.abort(); } catch { /* The transaction may already be closed. */ }
      await complete.catch(() => {});
      throw error;
    }
  }

  function metadata(work) {
    const { trashed, ...details } = work;
    return details;
  }

  async function readWork(store, id, trashed = false) {
    const work = await resultOf(store.get(id));
    if (!work || work.trashed !== trashed) throw new StorageError(404, '作品が見つかりません。');
    return work;
  }

  function titleOf(value, file) {
    if (typeof value !== 'string' || value.length > titleLimit || /[\r\n]/.test(value)) {
      throw new StorageError(400, `表示名は${titleLimit}文字以内で入力してください。`);
    }
    return value.trim() || file.name.slice(0, -file.ext.length).trim() || file.name;
  }

  function memoOf(value) {
    const memo = typeof value === 'string' ? value.replace(/\r\n?/g, '\n') : null;
    if (memo === null || memo.length > memoLimit) throw new StorageError(400, `メモは${memoLimit}文字以内で入力してください。`);
    return memo;
  }

  function fileInfo(file, format, label) {
    const name = file instanceof Blob && typeof file.name === 'string' ? file.name : '';
    const ext = /\.[^.]+$/.exec(name)?.[0].toLowerCase();
    const type = formats[format][ext];
    if (!file?.size || !type) throw new StorageError(400, `${label}のファイル形式を確認してください。`);
    return { name, ext, type };
  }

  async function addWork(form) {
    const category = form.get('category');
    if (typeof category !== 'string' || !Object.hasOwn(categories, category)) throw new StorageError(400, '追加先を選んでください。');
    const { format } = categories[category];
    const primaryFile = form.get('file');
    const audioFile = form.get('audio');
    const reverseFile = form.get('reverse');
    const primary = fileInfo(primaryFile, format, '作品ファイル');
    if (audioFile?.size && category !== 'score') throw new StorageError(400, '試聴音源は楽譜に追加できます。');
    if (reverseFile?.size && format !== 'image') throw new StorageError(400, '裏面の画像はイラストに追加できます。');
    const audio = audioFile?.size ? fileInfo(audioFile, 'audio', '試聴音源') : null;
    const reverse = reverseFile?.size ? fileInfo(reverseFile, 'image', '裏面の画像') : null;
    if (primaryFile.size + (audioFile?.size || 0) + (reverseFile?.size || 0) > maxBytes) {
      throw new StorageError(413, 'ファイルの合計は150 MBまでです。');
    }

    const id = runtime.crypto.randomUUID();
    const work = { id, category, title: titleOf(form.get('title') ?? '', primary), memo: memoOf(form.get('memo') ?? ''),
      primary, audio, reverse, createdAt: new Date().toISOString(), trashed: false };
    const media = {};
    for (const [kind, file] of [['primary', primaryFile], ['audio', audioFile], ['reverse', reverseFile]]) {
      if (!work[kind]) continue;
      try {
        // Read browser-selected files before opening the database transaction.
        media[kind] = new Blob([await file.arrayBuffer()], { type: work[kind].type });
      } catch {
        throw new StorageError(400, `「${work[kind].name}」を読み込めません。端末に保存してから選び直してください。`);
      }
    }
    return transaction(['works', 'media'], 'readwrite', tx => {
      tx.objectStore('works').add(work);
      for (const [kind, file] of Object.entries(media)) tx.objectStore('media').add(file, [id, kind]);
      return metadata(work);
    });
  }

  function getWork(id) {
    return transaction('works', 'readonly', async tx => metadata(await readWork(tx.objectStore('works'), id)));
  }

  function listWorks(trashed = false) {
    return transaction('works', 'readonly', async tx => {
      const works = await resultOf(tx.objectStore('works').getAll());
      return works.filter(work => work.trashed === trashed).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).map(metadata);
    });
  }

  function editWork(id, fields) {
    if (!fields || typeof fields !== 'object' || !Object.keys(fields).length ||
        Object.keys(fields).some(key => !['title', 'memo'].includes(key))) {
      throw new StorageError(400, '保存する内容を確認してください。');
    }
    return transaction('works', 'readwrite', async tx => {
      const store = tx.objectStore('works');
      const work = await readWork(store, id);
      if (Object.hasOwn(fields, 'title')) work.title = titleOf(fields.title, work.primary);
      if (Object.hasOwn(fields, 'memo')) work.memo = memoOf(fields.memo);
      store.put(work);
      return metadata(work);
    });
  }

  function moveWork(id, toTrash) {
    return transaction('works', 'readwrite', async tx => {
      const store = tx.objectStore('works');
      const work = await readWork(store, id, !toTrash);
      work.trashed = toTrash;
      store.put(work);
      return metadata(work);
    });
  }

  function purgeWork(id) {
    return transaction(['works', 'media'], 'readwrite', async tx => {
      const works = tx.objectStore('works');
      const work = await readWork(works, id, true);
      const media = tx.objectStore('media');
      for (const kind of ['primary', 'audio', 'reverse']) if (work[kind]) media.delete([id, kind]);
      works.delete(id);
      return { id };
    });
  }

  function getMedia(id, kind) {
    return transaction(['works', 'media'], 'readonly', async tx => {
      const work = await readWork(tx.objectStore('works'), id);
      const info = work[kind];
      const blob = info && await resultOf(tx.objectStore('media').get([id, kind]));
      if (!blob) throw new StorageError(404, 'ファイルが見つかりません。');
      const file = blob.type === info.type ? blob : blob.slice(0, blob.size, info.type);
      return { info, file };
    });
  }

  function readBackup() {
    return transaction(['works', 'media'], 'readonly', async tx => {
      const works = await resultOf(tx.objectStore('works').getAll());
      const media = tx.objectStore('media');
      return Promise.all(works.map(async work => {
        const files = {};
        await Promise.all(['primary', 'audio', 'reverse'].map(async kind => {
          if (!work[kind]) return;
          const file = await resultOf(media.get([work.id, kind]));
          if (!file?.size) throw new StorageError(404, `「${work.title}」のファイルが見つかりません。`);
          files[kind] = file;
        }));
        return { work, files };
      }));
    });
  }

  function restoreBackup(records, replaceExisting) {
    return transaction(['works', 'media'], 'readwrite', async tx => {
      const works = tx.objectStore('works');
      const media = tx.objectStore('media');
      let restored = 0;
      let updated = 0;
      for (const { work, files } of records) {
        const exists = Boolean(await resultOf(works.getKey(work.id)));
        if (exists && !replaceExisting) continue;
        works.put(work);
        for (const kind of ['primary', 'audio', 'reverse']) {
          if (files[kind]) media.put(files[kind], [work.id, kind]);
          else if (exists) media.delete([work.id, kind]);
        }
        if (exists) updated++;
        else restored++;
      }
      return { restored, updated, skipped: records.length - restored - updated };
    });
  }

  function failureMessage(error) {
    if (error.status) return error.message;
    if (error.name === 'QuotaExceededError') return 'ブラウザーの保存容量が足りません。';
    if (['InvalidStateError', 'SecurityError', 'NotAllowedError'].includes(error.name)) {
      return 'ブラウザーでサイトデータの保存が制限されています。通常のウィンドウで開き直してください。';
    }
    return '処理できませんでした。ページを開き直してお試しください。';
  }

  runtime.archiveStorage = { addWork, getWork, listWorks, editWork, moveWork, purgeWork, getMedia,
    readBackup, restoreBackup, failureMessage };
})(globalThis);
