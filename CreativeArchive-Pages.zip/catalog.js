(function (target) {
  const categories = Object.freeze({
    score: { label: '楽譜', collection: 'music', format: 'pdf' },
    basics: { label: '基礎練習', collection: 'music', format: 'note' },
    voice: { label: '歌唱・発声メモ', collection: 'music', format: 'note' },
    oboe: { label: 'オーボエ練習', collection: 'music', format: 'note' },
    'other-note': { label: 'その他メモ', collection: 'music', format: 'note' },
    illustration: { label: '挿絵', collection: 'art', format: 'image' },
    'other-art': { label: 'その他', collection: 'art', format: 'image' },
  });

  const formats = {
    pdf: { '.pdf': 'application/pdf' },
    image: {
      '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png',
      '.webp': 'image/webp', '.gif': 'image/gif', '.avif': 'image/avif',
    },
    note: { '.txt': 'text/plain', '.md': 'text/plain', '.pdf': 'application/pdf' },
    audio: {
      '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.m4a': 'audio/mp4',
      '.aac': 'audio/aac', '.ogg': 'audio/ogg', '.oga': 'audio/ogg', '.flac': 'audio/flac',
    },
  };

  target.archiveCatalog = { categories, formats, maxBytes: 150 * 1024 * 1024, titleLimit: 160, memoLimit: 4000 };
})(typeof module === 'object' && module.exports ? module.exports : globalThis);
